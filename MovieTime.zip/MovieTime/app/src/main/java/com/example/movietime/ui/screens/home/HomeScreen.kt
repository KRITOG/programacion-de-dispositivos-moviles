package com.example.movietime.ui.screens.home

import androidx.compose.foundation.layout.* // Import para Column, Spacer, Modifier, etc.
import androidx.compose.material.* // Import para Scaffold, TopAppBar, Button, Text, etc.
import androidx.compose.runtime.Composable // Import para @Composable
import androidx.compose.ui.Modifier // Import para Modifier
import androidx.compose.ui.unit.dp // Import para dp
import androidx.navigation.NavController
import com.example.movietime.ui.Screen

@Composable
fun HomeScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Home") },
                backgroundColor = MaterialTheme.colors.primary
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text("Welcome to MovieTime!")
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        navController.navigate(Screen.Favorites.route)
                    }
                ) {
                    Text("Go to Favorites")
                }
            }
        }
    )
}
