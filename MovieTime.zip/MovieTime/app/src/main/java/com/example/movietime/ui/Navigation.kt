package com.example.movietime.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.movietime.ui.screens.home.HomeScreen
import com.example.movietime.ui.screens.details.DetailsScreen
import com.example.movietime.ui.screens.favorites.FavoritesScreen

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Details : Screen("details/{movieId}") {
        fun createRoute(movieId: String) = "details/$movieId"
    }
    object Favorites : Screen("favorites")
}

@Composable
fun Navigation(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(route = Screen.Home.route) {
            HomeScreen(navController)
        }
        composable(route = Screen.Details.route) { backStackEntry ->
            val movieId = backStackEntry.arguments?.getString("movieId")
            DetailsScreen(navController, movieId)
        }
        composable(route = Screen.Favorites.route) {
            FavoritesScreen(navController)
        }
    }
}
