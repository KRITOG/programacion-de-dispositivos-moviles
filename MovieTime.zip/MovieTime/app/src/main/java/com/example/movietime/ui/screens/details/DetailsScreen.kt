package com.example.movietime.ui.screens.details

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.* // Import para Column, Spacer, Modifier, etc.
//noinspection UsingMaterialAndMaterial3Libraries
import androidx.compose.material.* // Import para Scaffold, TopAppBar, Button, Text, etc.
import androidx.compose.runtime.Composable // Import para @Composable
import androidx.compose.ui.Modifier // Import para Modifier
import androidx.compose.ui.unit.dp // Import para dp
import androidx.navigation.NavController

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun DetailsScreen(navController: NavController, movieId: String?) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Details") },
                backgroundColor = MaterialTheme.colors.primary
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text("Details for Movie ID: $movieId")
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { navController.popBackStack() }
                ) {
                    Text("Back to Home")
                }
            }
        }
    )
}
