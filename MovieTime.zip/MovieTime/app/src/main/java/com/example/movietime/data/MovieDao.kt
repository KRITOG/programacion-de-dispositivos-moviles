package com.example.movietime.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MovieDao {
    // Inserción de una película
    @Insert
    suspend fun insert(movie: Movie)

    // Obtener todas las películas
    @Query("SELECT * FROM movies")
    fun getAllMovies(): Flow<List<Movie>> // Cambiado a Flow para soporte asincrónico
}
