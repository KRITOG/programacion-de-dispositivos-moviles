package com.example.movietime.ui.theme

import androidx.compose.ui.graphics.Color

// Colores Primarios
val Red500 = Color(0xFFF44336)
val Red700 = Color(0xFFD32F2F)
val Yellow500 = Color(0xFFFFEB3B)
